from flask import Flask, request, jsonify
import pandas as pd
from copy import deepcopy
from wordle_agent import WordleAPI
from hangman_agent import HangmanAPI
from word_ladder_agent import WordLadderAPI
import random
from collections import deque
import csv
import logging
import os

app = Flask(_name_)

logging.basicConfig(level=logging.DEBUG)
file_handler = logging.FileHandler('app.log')
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
app.logger.addHandler(file_handler)

with open('/app/base', 'r') as f:
    words = [line.strip() for line in f if len(line.strip()) == 5]

with open('/app/base', 'r') as f:
    ladder_words = [line.strip() for line in f if len(line.strip()) == 4]

with open('/app/base', 'r') as f:
    hangman_words = [line.strip() for line in f]

secret_word = None
attempts_left = 0
hangman_secret_word = None
hangman_attempts_left = 0
hangman_game_state = None
correct_letters = []
custom_words = []
use_custom_dictionary = os.environ.get('USE_CUSTOM_DICTIONARY', 'False').lower() == 'true'

def read_csv_words(csv_path):
    dict_words = []
    try:
        with open(csv_path, 'r') as csv_file:
            for line in csv_file:
                words = line.strip().split(',')
                dict_words.extend(words)
    except Exception as e:
        app.logger.warning("Error reading CSV:" + str(e))
    app.logger.warning(dict_words)
    return dict_words

@app.route('/wordle/start_game', methods=['POST'])
def start_game():
    global secret_word, attempts_left, custom_words
    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        app.logger.warning(custom_words)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = words
    
    app.logger.warning(custom_words)

    secret_word = random.choice(custom_words)
    app.logger.warning(secret_word)
    attempts_left = 6
    response = {
        'message': 'Welcome to Wordle!',
        'attempts_left': attempts_left
    }
    return jsonify(response)

@app.route('/wordle/guess', methods=['POST'])
def make_guess():
    global secret_word, attempts_left
    if not secret_word:
        return jsonify({'error': 'Game has not been started. Use /start_game endpoint.'}), 400

    guess = request.json.get('guess', '').lower()
    app.logger.warning('Debugging in make_guess')
    app.logger.warning(custom_words)
    if len(guess) != len(secret_word):
        return jsonify({'error': 'Invalid guess. The word must be 5 letters long.'}), 400

    if guess not in custom_words:
        return jsonify({'error': 'Invalid guess. The word must be in the dictionary.'}), 400

    feedback = process_guess(guess)
    attempts_left -= 1

    response = {
        'feedback': feedback,
        'attempts_left': attempts_left
    }

    if guess == secret_word:
        response['message'] = 'Congratulations! You guessed the secret word.'
        secret_word = None

    elif attempts_left <= 0:
        response['message'] = f'Sorry, you have run out of attempts. The secret word was {secret_word}.'
        secret_word = None

    return jsonify(response)


def process_guess(guess):
    global secret_word

    correct_positions = []
    correct_letters_wrong_position = []
    incorrect_letters = []

    for i in range(len(secret_word)):
        if guess[i] == secret_word[i]:
            correct_positions.append(guess[i])
        elif guess[i] in secret_word:
            correct_letters_wrong_position.append(guess[i])
        else:
            incorrect_letters.append(guess[i])

    feedback = {
        'correct_positions': ' '.join(correct_positions),
        'correct_letters_wrong_position': ' '.join(correct_letters_wrong_position),
        'incorrect_letters': ' '.join(incorrect_letters)
    }

    return feedback

class Game:
    def _init_(self, letters):
        self.letters = letters
        self.board = []  # Initialize your board
        self.g_count = 0

class Wordle:
    def _init_(self, word, rows=6, letters=5):
        self.g_count = 0
        self.word = word
        self.w_hash_table = {}
        if word is not None:
            for x, l in enumerate(word):
                if l in self.w_hash_table:
                    self.w_hash_table[l]['count'] += 1
                    self.w_hash_table[l]['pos'].append(x)
                else:
                    self.w_hash_table[l] = {'count':1, 'pos':[x]}
        self.rows = rows
        self.letters = letters
        self.board = [['' for _ in range(letters)] for _ in range(rows)]
        self.colours = [['' for _ in range(letters)] for _ in range(rows)]
        self.alph = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

    def is_end(self):
        if self.board[-1] != ['' for _ in range(self.letters)]:
            return True
        else:
            r = self.game_result()
            if r[0] == True:
                return True
            else:
                return False

    def game_result(self):
        win = (False, 99)
        for i, r in enumerate(self.board):
            if self.word == ''.join(r):
                win = (True, i)
                break
        return win

    def update_board(self, u_inp):
        w_hash_table = deepcopy(self.w_hash_table)
        i_hash_table = {}
        for x, l in enumerate(str(u_inp).upper()):
            self.board[self.g_count][x] = l
            if l in i_hash_table:
                i_hash_table[l].append(x)
            else:
                i_hash_table[l] = [x]
        colours = {'G':[],'B':[],'Y':[]}
        for l in i_hash_table:
            if l in w_hash_table:
                g_hold = []
                for p in i_hash_table[l]:
                    if p in w_hash_table[l]['pos']:
                        g_hold.append(p)
                for p in g_hold:
                    i_hash_table[l].remove(p)
                colours['G'] += g_hold
                if len(g_hold) < w_hash_table[l]['count']:
                    y_hold = []
                    for p in i_hash_table[l]:
                        y_hold.append(p)
                        if len(y_hold) == w_hash_table[l]['count']:
                            break
                    for p in y_hold:
                        i_hash_table[l].remove(p)
                    colours['Y'] += y_hold
                for p in i_hash_table[l]:
                    colours['B'].append(p)
            else:
                colours['B'] += i_hash_table[l]
                i_hash_table[l] = []
        for c in colours:
            for p in colours[c]:
                self.colours[self.g_count][p] = c
        self.g_count += 1

    def valid_guess(self, u_inp):
        if len(u_inp) == 5 and False not in [False for s in str(u_inp).upper() if s not in self.alph]:
            return True
        else:
            return False
        
ROWS = 6
LETTERS = 5
GAMES = 1
w_bank = pd.read_csv('wordle_words.csv')
w_bank = w_bank[w_bank['words'].str.len() == LETTERS]
w_bank['words'] = w_bank['words'].str.upper()

@app.route('/wordle/agent', methods=['POST'])
def play_wordle_agent():
    global secret_word, attempts_left, custom_words

    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = words

    if not secret_word:
        secret_word = random.choice(custom_words)

    word = random.choice(w_bank['words'].tolist())
    game = Wordle(word, rows=ROWS, letters=LETTERS)
    bot = WordleAPI(game)
    guessed_words = []

    while not game.is_end():
        agent_guess = bot.choose_action()
        guessed_words.append(agent_guess)
        if game.valid_guess(agent_guess):
            game.update_board(agent_guess)

    result = game.game_result()
    response = {
        'word': word,
        'result': result[0],
        'moves': result[1] + 1,
        'guessed_words': guessed_words
    }
    return jsonify(response)

@app.route('/hangman/start_game', methods=['POST'])
def start_hangman_game():
    global hangman_secret_word, hangman_attempts_left, hangman_game_state, correct_letters
    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        app.logger.warning(custom_words)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = words
    
    app.logger.warning(custom_words)
    hangman_secret_word = random.choice(custom_words)
    hangman_attempts_left = 6
    hangman_game_state = None
    correct_letters = ['_'] * len(hangman_secret_word)  # Initialize with underscores
    response = {
        'message': 'Welcome to Hangman! The secret word is of '+ str(len(hangman_secret_word)) +' letters',
        'attempts_left': hangman_attempts_left
    }
    return jsonify(response)

@app.route('/hangman/guess', methods=['POST'])
def make_hangman_guess():
    global hangman_secret_word, hangman_attempts_left, hangman_game_state, correct_letters
    if not hangman_secret_word:
        return jsonify({'error': 'Game has not been started. Use /hangman/start_game endpoint.'}), 400

    guess = request.json.get('guess', '').lower()
    if len(guess) != 1 or not guess.isalpha():
        return jsonify({'error': 'Invalid guess. Please enter a single letter.'}), 400

    feedback = process_hangman_guess(guess)

    response = {
        'feedback': feedback,
        'attempts_left': hangman_attempts_left
    }

    if guess in hangman_secret_word:
        for i, letter in enumerate(hangman_secret_word):
            if letter == guess:
                correct_letters[i] = letter
        response['message'] = f'Word guessed till now : {correct_letters}\nLetter {guess} is present in the secret word.'
        
        if correct_letters == list(hangman_secret_word):
            hangman_game_state = 'win'
            response['message'] = 'Congratulations! You have correctly guessed the secret word.'
    else:
        hangman_attempts_left -= 1
        response['attempts_left'] -= 1
        response['message'] = f'Word guessed till now : {correct_letters}\n. Wrong guess !!'

        if hangman_attempts_left <= 0:
            hangman_game_state = 'lose'
            response['message'] = f'Sorry, you have run out of attempts. The secret word was {hangman_secret_word}.'
            hangman_secret_word = None

    return jsonify(response)

def process_hangman_guess(guess):
    global hangman_secret_word

    feedback = []
    for i, letter in enumerate(hangman_secret_word):
        if letter == guess:
            feedback.append((letter, i + 1))

    return feedback

hangmanAPI_instance = HangmanAPI()

@app.route('/hangman/agent', methods=['GET'])
def play_hangman_agent():
    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        app.logger.warning(custom_words)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = hangman_words

    hangmanAPI_instance.reset()
    global hangman_secret_word, attempts_left, hangman_game_state, correct_letters
    hangman_secret_word = random.choice(custom_words)
    correct_letters = ['_', ' ']*len(hangman_secret_word)
    app.logger.warning(secret_word)
    attempts_left = 6
    hangmanAPI_instance.guessed_letters = []
    responses = []

    while attempts_left > 0:
        app.logger.warning(attempts_left)
        app.logger.warning(hangman_secret_word)
        agent_guess = hangmanAPI_instance.guess(''.join(correct_letters))

        if len(agent_guess) != 1 or not agent_guess.isalpha():
            responses.append({'error': 'Invalid guess. Please enter a single letter.'})
            break

        # prev_attempt = attempts_left

        feedback = process_hangman_guess(agent_guess)

        response = {
            'agent_guess': agent_guess,
            'feedback': feedback,
            'attempts_left': attempts_left
        }

        if agent_guess in hangman_secret_word:
            app.logger.warning(attempts_left)
            correct_letters = [
                letter if letter == agent_guess else correct_letters[i]
                for i, letter in enumerate(hangman_secret_word)
            ]
            app.logger.warning(correct_letters)
            response['message'] = f'Word guessed till now : {correct_letters}\nLetter {agent_guess} is present in the secret word.'

            if ''.join(correct_letters).replace(" ", "") == hangman_secret_word:
                hangman_game_state = 'win'
                response['message'] = 'Congratulations! You have correctly guessed the secret word.'
                break
        else:
            app.logger.warning(attempts_left)
            app.logger.warning(correct_letters)
            attempts_left -= 1
            response['attempts_left'] -= 1
            response['message'] = f'Word guessed till now : {correct_letters}\n. Wrong guess !!'

        # if prev_attempt > attempts_left:
        #     was_guess_correct = False
        # else:
        #     was_guess_correct = True

        hangmanAPI_instance.upd(agent_guess)

        responses.append(response)

    if attempts_left <= 0:
        hangman_game_state = 'lose'
        response['message'] = f'Sorry, you have run out of attempts. The secret word was {hangman_secret_word}.'
        hangman_secret_word = None
        responses.append(response)

    return jsonify(responses)

def findWordLadder():  
    global ladder, startWord, endWord
    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        app.logger.warning(custom_words)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = words
    
    startWord, endWord = random.sample(custom_words, 2)  
    wordSet = set(custom_words)
    queue = deque([(startWord, [startWord])])
    visited = set()
    parents = {}
    ladder = []

    while queue:
        currentWord, ladder = queue.popleft()
        visited.add(currentWord)

        if len(ladder)<4:
            for i in range(len(currentWord)):
                for char in 'abcdefghijklmnopqrstuvwxyz':
                    nextWord = currentWord[:i] + char + currentWord[i+1:]

                    if nextWord in wordSet and nextWord not in visited:
                        queue.append((nextWord, ladder + [nextWord]))
                        visited.add(nextWord)
                        parents[nextWord] = currentWord

                        if nextWord == endWord:
                            ladder = ladder + [endWord]
        else:
            break
    app.logger.warning(ladder)

    return []

@app.route('/word_ladder/start_game', methods=['GET'])
def word_ladder_start_game():
    global startWord, endWord, ladder, current_word, guessed_words
    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        app.logger.warning(custom_words)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = words

    startWord = random.sample(custom_words, 1)

    findWordLadder()
    endWord = ladder[-1]
    current_word = startWord
    guessed_words = []
    
    response = {
        'message': 'Welcome to Word Ladder!',
        'start_word': startWord,
        'end_word': endWord
    }
    
    return jsonify(response)

@app.route('/word_ladder/guess', methods=['POST'])
def word_ladder_make_guess():
    global current_word, guessed_words

    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        app.logger.warning(custom_words)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = words
    
    if not current_word:
        return jsonify({'error': 'Game has not been started. Use /start_game endpoint.'}), 400
    
    guess = request.json.get('guess', '').lower()
    
    if len(guess) != len(current_word):
        return jsonify({'error': 'Invalid guess. The word must be of the same length.'}), 400
    
    if guess not in custom_words:
        return jsonify({'error': 'Invalid guess. The word must be in the dictionary.'}), 400
    
    if sum(c1 != c2 for c1, c2 in zip(guess, current_word)) != 1:
        return jsonify({'error': 'Invalid guess. The word must have only one letter changed from the previous word.'}), 400
    
    if guess == endWord:
        response = {
            'message': 'Congratulations! You have successfully completed the word ladder!',
            'word_ladder': guessed_words + [current_word, guess]
        }
        current_word = None
        guessed_words = []
    else:
        current_word = guess
        guessed_words.append(guess)
        response = {
            'message': 'Guess accepted. Keep going!',
            'current_word': current_word
        }
    
    return jsonify(response)

word_ladder_api = WordLadderAPI()

@app.route('/word_ladder/agent', methods=['GET'])
def word_ladder_agent():
    global startWord, endWord, ladder, current_word, guessed_words
    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        app.logger.warning(custom_words)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = words

    startWord = random.sample(custom_words, 1)
    findWordLadder()
    endWord = ladder[-1]
    agent_guessed_ladder = word_ladder_api.word_transformer(startWord, endWord, custom_words)

    response = {
        'start_word': startWord,
        'end_word': endWord,
        'ladder_path': agent_guessed_ladder
    }

    return jsonify(response)

@app.route('/scrambled_word/start_game', methods=['GET'])
def start_scrambled_game():
    global target_word, scrambled_word, attempts_left, custom_words

    custom_csv_path = '/app/custom_dictionary/dictionary.csv'

    if use_custom_dictionary:
        custom_words = read_csv_words(custom_csv_path)
        app.logger.warning(custom_words)
        if not custom_words:
            return jsonify({'error': 'Custom CSV dictionary is empty or could not be read.'}), 400
    else:
        custom_words = []

    if not custom_words:
        custom_words = words
    
    target_word = random.choice(custom_words).upper()
    scrambled_word = scramble_word(target_word)
    attempts_left = 6  # Set the number of attempts
    
    response = {
        'message': 'Welcome to Scrambled Word Game!',
        'scrambled_word': scrambled_word,
        'attempts_left': attempts_left
    }
    
    return jsonify(response)

@app.route('/scrambled_word/guess', methods=['POST'])
def make_scrambled_guess():
    global attempts_left
    
    if attempts_left <= 0:
        response = {
            'message': 'Sorry, you have run out of attempts. The word was ' + target_word,
            'target_word': target_word
        }
    else:
        guess = request.json.get('guess', '').strip().upper()
        
        if guess == target_word:
            response = {
                'attempts_left': attempts_left,
                'message': 'Congratulations! You guessed the word!',
                'target_word': target_word
            }
        else:
            attempts_left -= 1
            if attempts_left > 0:
                response = {
                    'message': 'Sorry, your guess is incorrect. Keep trying!',
                    'scrambled_word': scrambled_word,
                    'attempts_left': attempts_left
                }
            else:
                response = {
                    'message': 'Sorry, you have run out of attempts. The word was ' + target_word,
                    'target_word': target_word
                }
    
    return jsonify(response)

def scramble_word(word):
    word_chars = list(word)
    random.shuffle(word_chars)
    return ''.join(word_chars)

if _name_ == '_main_':
    app.run(host='0.0.0.0', port=5000)